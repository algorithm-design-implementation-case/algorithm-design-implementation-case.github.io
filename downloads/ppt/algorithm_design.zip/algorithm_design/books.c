#include"util.h"


int current_step(int start, int end, int* f) {
	if (start > end) return 0;
	int si = 1;
	for (int j = start; j < end; j++) { 
		if (f[j] != f[j + 1]) si++;
	}
	si++;
	return si;
}

int getkg(int start, int end, int* w) {
	int wi = 0;
	for (int j = start; j <= end; j++) {
		wi += w[j];
	}
	return wi;
}

int min_step(int start, int end, int* f, int* w, int maxbook, int maxkg) {
	if (start > end) return 0;
	if (start == end) {
		// ���ֻ��һ���飬�Ҳ�����Լ������������Ҫ��2��
		if ((end < start + maxbook) && (w[start] <= maxkg)) return 2;
		else return -1;
	}
	
	int r = 100000000;
	int i = start;
	while ((i < start + maxbook) && (i <= end) && (getkg(start, i, w) <= maxkg)) {
		int temp = current_step(start, i, f) + min_step(i + 1, end, f, w, maxbook, maxkg);
		if (temp < r) {
			r = temp;
		}
		i++;
	}
	return r;

}
//
//int main() {
//
//	int f[9] = {2,2,3,3,3,3,4,1,5};
//	int w[9] = {4,5,1,2,7,1,4,3,2};
//	int frindsCoun = 5;
//	int maxbooks = 5;
//	int maxkgs = 7;
//
//	printf("f: ");
//	print_int_array(f, 9);
//	printf("w: ");
//	print_int_array(w, 9);
//	printf("maxbooks: %3d\n", maxbooks);
//	printf("maxkgs: %3d\n", maxkgs);
//
//	//printf("%d\n", current_step(0, 2, f));
//	//printf("%d\n", getkg(0, 2, w));
//
//	int r = min_step(0, 8, f, w, maxbooks, maxkgs);
//	printf("min steps: %d\n", r);
//
//	return 0;
//}